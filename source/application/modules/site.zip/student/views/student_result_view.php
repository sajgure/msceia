<div class="form-body">
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover datatable" data-url="<?php echo $url; ?>">
			<thead>
                <tr>
                    <th class="font-blue-madison bold" style="text-align: center;">#</th>
                    <th class="font-blue-madison bold"> Institute Name/ Code</th>
                    <th class="font-blue-madison bold" > Student Name</th>
                    <th class="font-blue-madison bold"> Seat No &<br>Password</th>
                    <th class="font-blue-madison bold"> Course Name</th>
                    <th class="font-blue-madison bold" > Objective</th>
                    <th class="font-blue-madison bold" > Email</th>
                    <th class="font-blue-madison bold" > Letter</th>
                    <th class="font-blue-madison bold" > Statement</th>
                    <th class="font-blue-madison bold" > Speed</th>
                    <th class="font-blue-madison bold" > Mobile Computing</th>
                    <th class="font-blue-madison bold" > Total Marks</th>
                    <th class="font-blue-madison bold"> Result</th>
                    <th class="font-blue-madison bold"> Action</th>

                </tr>
            </thead>
			<tbody> 
			</tbody>
		</table>
	</div>		
</div>