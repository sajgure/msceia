<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Web_controller extends Base_Controller
{

  public function __construct()
  { 
    parent::__construct();
    $this->load->model('common_model');          
    $this->load->model('web_model');    
    date_default_timezone_set("Asia/Kolkata");   
  } 
  
  public function fetchPinCodeWiseInst()
  {
      $data = json_decode(file_get_contents('php://input'),true);
      $inst_pin_code = $data['inst_pin_code'];
      $inst_data = $this->web_model->fetchPinCodeWiseInst($inst_pin_code);
      if(isset($inst_data) && !empty($inst_data))
      {
          $json=array('status'=>1,'inst_data'=>$inst_data);
      }
      else
      {
          $json=array('status'=>0,'inst_data'=>'No Record Found');
      }
      echo json_encode($json);
  }

  public function check_user()
    {
        $data = json_decode(file_get_contents('php://input'),true);
        $inst_code = $data['inst_code'];
        $password = $data['password'];
        $mack = $data['mack'];
        $type = (isset($data['type']) && !empty($data['type']))?$data['type']:'demo';

        $result = $this->web_model->get_inst_data($inst_code,$password);
        if(isset($result) && !empty($result))
        {
            $user_id=$result->inst_id;
            if($type=='exam')
            {
                $stud_data = $this->web_model->fetch_exam_student($user_id);
                $test = $this->db->last_query();
                $data1 = array('db_status'=>'exam install');
                $this->common_model->updateDetails('tbl_institute','institute_id',$user_id,$data1);
                $json=array(
                    'status'=>1,
                    'test'=>$test,
                    'stud_data'=>$stud_data,
                    'inst_data'=>$result,
                    'msg'=>'<strong>Well Done!</strong>Software installed Successfully!'
                );
            }
            else
            {
                if($result->db_status=='download')
                { 
                    if(isset($result->exam_mac_id) && !empty($result->exam_mac_id))
                    { 
                        $mac = explode(',', $result->exam_mac_id);
                        if(in_array($mack, $mac))
                        {
                            $mack_id=$result->exam_mac_id;
                        }
                        else
                        {
                            $mack_id=$result->exam_mac_id.','.$mack;
                        }
                    }
                    else
                    {
                        $mack_id=$mack;
                    }
                    $data1 = array(
                        'db_status'=>'install',
                        'exam_mac_id'=>$mack_id
                    );
                    $this->common_model->updateDetails('tbl_institute','institute_id',$user_id,$data1);
                    $json=array(
                        'status'=>1,
                        'inst_data'=>$result,
                        'msg'=>'<strong>Well Done!</strong>Software installed Successfully!'
                    );
                }
                else
                {
                    $mac = explode(',', $result->exam_mac_id);
                    if(in_array($mack, $mac))
                    {
                        $json=array(
                            'status' => 1,
                            'db_status'=>'install',
                            'inst_data'=>$result,
                            'msg'=>'<strong>Well Done!</strong>Software installed Successfully!'
                        );
                    }
                    else
                    {
                        $json=array(
                            'status' => 0,
                            'msg'=>'<strong>Error!</strong> This Software Running On Another Computer , Please contact to MSCEIA Team...!'
                        );
                    }
                }
            }
        }
        else
        {           
            $json=array(
                'status' => 0,
                'msg'=>'<strong>Error!</strong> You Enter Wrong Username or Password!'
            );
        }
        echo json_encode($json);
    }
  
    public function get_msceia_student()
    {    
        $data = json_decode(file_get_contents('php://input'),true);
        $id= $data['id'];
        $stud_data = $this->web_model->fetch_elearn_student($id);
        $dir = './download/exam_'.$id;
        if(file_exists($dir))
        {
            $link='./download/exam_'.$id.'/stud_photos';
            array_map('unlink', glob("$link/*.*"));
            rmdir($link);
            $link='./download/exam_'.$id;
            array_map('unlink', glob("$link/*.*"));
            rmdir($link);
        }
        $link='./download/exam_'.$id;
        mkdir($link);
        $link='./download/exam_'.$id.'/stud_photos';
        mkdir($link);
        $source1='./uploads/student_photos/user.png';
        $target1=$link.'/user.png';
        copy($source1,$target1);
        foreach ($stud_data as $key) 
        {
            if(isset($key->stud_photo) && !empty($key->stud_photo))
            {
                $path1 = './uploads/student_photos/'.$key->stud_photo;
                if(file_exists($path1))
                {
                    $source='./uploads/student_photos/'.$key->stud_photo;
                    $target=$link.'/'.$key->stud_photo;
                    copy($source,$target);
                }
            }
        } 
        $rootPath = realpath($dir);
        $archive = './download/exam_'.$id.'.zip';
        $zip = new ZipArchive();
        $zip->open($archive, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($rootPath), RecursiveIteratorIterator::LEAVES_ONLY );
        foreach ($files as $dir => $file)
        {
            if (!$file->isDir())
            {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($rootPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        $file = file_get_contents($archive);
        $base64 = base64_encode($file);
        if(isset($stud_data) && !empty($stud_data))
        {
            $link1='./download/exam_'.$id;
            opendir($link1);
            $link2='./download/exam_'.$id.'/stud_photos';
            opendir($link2);
            $source1='./download/exam_'.$id.'/stud_photos/user.png';
            @unlink($source1);
            foreach ($stud_data as $key) 
            {
                if(isset($key->stud_photo) && !empty($key->stud_photo))
                {
                    $path1 = './uploads/student_photos/'.$key->stud_photo;
                    if(file_exists($path1))
                    {
                        $source='./uploads/student_photos/'.$key->stud_photo;
                        $target=$link.'/'.$key->stud_photo;
                        @unlink($target);
                    }
                }
            } 
            rmdir($link2);
            rmdir($link1);
            @unlink('./download/exam_'.$id.'.zip');
            $json = array(
                "status" => 1,
                "stud_data" => $stud_data,
                "base64"=>$base64
            );
        }
        else
        {
            $json = array("status" => 0);
        }
        echo json_encode($json);
    }


  public function check_update()
  {    
    $data = json_decode(file_get_contents('php://input'),true);
    $version_data= $data['version_data'];
    $myfile = fopen("./uploads/update/version.txt", "r") or die("Unable to open file!");
    $version = fread($myfile,filesize("./uploads/update/version.txt"));
    fclose($myfile);
    if($version>$version_data)
    {
        $next_version = $version_data+1;
        $versionData = $this->common_model->selectDetailsWhr('tbl_version','version',$next_version);
        $whatsnewData = $this->web_model->whatsnewData($next_version);
        $whatsnew = array();
        if (count($whatsnewData) > 0) {
           foreach ($whatsnewData as $rs) {
            $whatsnew[] = $rs;   
           }
        }
        $path='./uploads/update/'.$versionData->file_name;
        $file = file_get_contents($path);
        $base64 = base64_encode($file);
        $json = array("status" => 1,"base64"=>$base64,"name"=>$versionData->file_name,"db"=>$versionData->database,"exam"=>$versionData->exam,'whatsnew'=>$whatsnew);
    }
    else
    {
        $json = array("status" => 0);
    }
    echo json_encode($json);
  }

  public function app_login()
  {
    $data = json_decode(file_get_contents('php://input'),true);
    $username=$data['username'];
    $password=$data['password'];
    $mac_id=$data['mac_id'];
    $result = $this->web_model->stud_details($username,$password);
    if($result)
    {
      $json_data['stud_data']=$result;
      $json_data['question_data'] = $this->web_model->app_que();
      $json_data['previous_data'] = $this->web_model->previous_que();
      $json_data['section_data'] = $this->web_model->app_section_data();
      if(isset($result->mac_id) && !empty($result->mac_id))
      {
        if($mac_id==$result->mac_id)
        {
          $json = array("status" => 1,"msg"=>"login Successfully","json_data"=>$json_data);
        }
        else
        {
          $json = array("status" => 0,"msg"=>"Same user run on another mobile");
        }
      } 
      else
      {
        $data1 = array('mac_id'=>$mac_id);
        if($result->type=='stud')
        {
            $this->common_model->updateDetails('tbl_student','stud_seat_no',$username,$data1);
        }
        else
        {
             $this->common_model->updateDetails('tbl_institute','inst_code',$username,$data1);
        }
        $json = array("status" => 1,"msg"=>"login Successfully","json_data"=>$json_data,"type"=>$result->type);
      }
    }
    else
    {
      $json = array("status" => 0,"msg"=>"Invalid User");
    }
    echo json_encode($json);
  }
  
  public function app_login1()
  {
    $data = json_decode(file_get_contents('php://input'),true);
    $username='msa1979435';//$data['username'];
    $password='988383';//$data['password'];
    $mac_id='123455';//$data['mac_id'];
    $result = $this->web_model->stud_details($username,$password);
    if($result)
    {
      $json_data['stud_data']=$result;
      $json_data['question_data'] = $this->web_model->app_que();
      $json_data['previous_data'] = $this->web_model->previous_que();
      $json_data['section_data'] = $this->web_model->app_section_data();
      //print_r($json_data['question_data']);
      if(isset($result->mac_id) && !empty($result->mac_id))
      {
        if($mac_id==$result->mac_id)
        {
          $json = array("status" => 1,"msg"=>"login Successfully","json_data"=>$json_data);
        }
        else
        {
          $json = array("status" => 0,"msg"=>"Same user run on another mobile");
        }
      } 
      else
      {
        $data1 = array('mac_id'=>$mac_id);
        if($result->type=='stud')
        {
            $this->common_model->updateDetails('tbl_student','stud_seat_no',$username,$data1);
        }
        else
        {
             $this->common_model->updateDetails('tbl_institute','inst_code',$username,$data1);
        }
        $json = array("status" => 1,"msg"=>"login Successfully","json_data"=>$json_data,"type"=>$result->type);
      }
    }
    else
    {
      $json = array("status" => 0,"msg"=>"Invalid User");
    }
    //header('Content-Type: application/json; charset=utf-8');
    echo json_encode($json, JSON_UNESCAPED_UNICODE);
  }
  
  public function app_login2()
  {
    $data = json_decode(file_get_contents('php://input'),true);
    $username=$data['username'];
    $password=$data['password'];
    $mac_id=$data['mac_id'];
    /*$username='msa1979435';//$data['username'];
    $password='988383';//$data['password'];
    $mac_id='123455';//$data['mac_id'];*/
    $result = $this->web_model->stud_details($username,$password);
    
    if($result)
    {
      if(isset($result->mac_id) && !empty($result->mac_id))
      {
        if($mac_id==$result->mac_id)
        {
          $json = array("status" => 1,"msg"=>"login Successfully", "stud_data"=>$result);
        }
        else
        {
          $json = array("status" => 0,"msg"=>"Same user run on another mobile");
        }
      } 
      else
      {
        $data1 = array('mac_id'=>$mac_id);
        if($result->type=='stud')
        {
            $this->common_model->updateDetails('tbl_student','stud_seat_no',$username,$data1);
        }
        else
        {
             $this->common_model->updateDetails('tbl_institute','inst_code',$username,$data1);
        }
        //$json = array("status" => 1,"msg"=>"login Successfully","type"=>$result->type);
        $json = array("status" => 1,"msg"=>"login Successfully","stud_data"=>$result,"type"=>$result->type);
      }
    }
    else
    {
      $json = array("status" => 0,"msg"=>"Invalid User");
    }
    echo json_encode($json);
  }
  
  public function allQuesData()
  {
  	$ques_data = $this->web_model->app_que();
  	echo json_encode($ques_data, JSON_UNESCAPED_UNICODE);
  }
    
  public function onlyQuesData()
  {
    $ques_data = $this->web_model->app_only_question();
  	echo json_encode($ques_data, JSON_UNESCAPED_UNICODE);
  }
    
  public function onlyOptionData()
  {
      $option_data = $this->web_model->app_only_option();
      echo json_encode($option_data, JSON_UNESCAPED_UNICODE);
  }
  
  public function allPrevData()
  {
  	$prev_data = $this->web_model->previous_que();
  	echo json_encode($prev_data, JSON_UNESCAPED_UNICODE);
  }
  
  public function onlyPrevQuesData()
  {
    $ques_data = $this->web_model->app_only_prev_question();
  	echo json_encode($ques_data, JSON_UNESCAPED_UNICODE);
  }
  
  public function onlyPrevOptionData()
  {
    $option_data = $this->web_model->app_only_prev_option();
    echo json_encode($option_data, JSON_UNESCAPED_UNICODE);
  }
  
  public function allSecData()
  {
  	$ques_data = $this->web_model->app_section_data();
  	echo json_encode($ques_data, JSON_UNESCAPED_UNICODE);
  }

  public function fetch_video()
  {
    $json_data['video']= $this->common_model->fetchDataASC('tbl_video','video_id');
    $json = array("json_data"=>$json_data);
    echo json_encode($json);
  }

  public function get_version()
  {
    $data = json_decode(file_get_contents('php://input'),true);
    $json_data= $this->common_model->fetchDataDESClimit('tbl_app_version','version_id', 1);
    $version = $json_data[0]->version_no;
    $json = array("version"=>$version);
    echo json_encode($json);
  }
  
  public function check_fek_user()
  {
    $data = json_decode(file_get_contents('php://input'),true);
    $device_id=$data['device_id'];
    $student_id=$data['student_id'];
    $type=$data['type'];
    if($type=='stud')
    {
      $same_data = $this->common_model->selectDetailsWhr('tbl_student','stud_id',$student_id);
      if($same_data->mac_id==$device_id)
      {
        $json = array("status"=>true);
      }
      else
      {
        $json = array("status"=>false);
      }
    }
    else
    { 
      $same_data = $this->common_model->selectDetailsWhr('tbl_institute','inst_id',$student_id);
      if($same_data->mac_id==$device_id)
      {
        $json = array("status"=>true);
      }
      else
      {
        $json = array("status"=>false);
      }
    }
    echo json_encode($json);
  }

  public function redirect_link()
  {
    redirect('https://play.google.com/store/apps/details?id=com.info.itwizz.msceiaexamapplication');
  }
  
  public function upload_db()
  {
    $data = json_decode(file_get_contents('php://input'),true);
    $stud_data= $data['stud_data'];
    parse_str($stud_data, $stud_output);
    $data1 = array('db_status'=>'Upload'); 
    $stud_id = array();
    
    foreach ($stud_output as $key) 
    {
        $this->db->trans_start();
        $stud_data=$key['stud_data'];
        if(isset($key['ans_data']) && !empty($key['ans_data']))
        {
          $ans_data=$key['ans_data']; 
          $result_data = $this->common_model->selectDetailsWhr('tbl_student','student_id',$stud_data['stud_id']);
          
          if(isset($result_data->exam_status) && !empty($result_data->exam_status) && ($result_data->exam_status=='Pending'))
          {
              
              $s_data=array('exam_status'=>'Upload','objective_marks'=>$stud_data['objective_marks'],'email_marks'=>$stud_data['email_marks'],'speed_marks'=>$stud_data['speed_marks'],'letter_marks'=>$stud_data['letter_marks'],'statement_marks'=>$stud_data['statement_marks'],'mobile_marks'=>$stud_data['mobile_marks'],'submit_on'=>$stud_data['submit_on'],'grace'=>$stud_data['grace']);              
              $r_data=array('student_id'=>$stud_data['stud_id'],'objective_marks'=>$stud_data['objective_marks'],'email_id'=>$stud_data['email_id'],'to'=>$stud_data['to'],'cc'=>$stud_data['cc'],'bcc'=>$stud_data['bcc'],'subject'=>$stud_data['subject'],'message'=>$stud_data['message'],'attachment_file'=>$stud_data['attachment_file'],'attachment_file1'=>$stud_data['attachment_file1'],'email_marks'=>$stud_data['email_marks'],'speed_id'=>$stud_data['speed_id'],'passage'=>$stud_data['passage'],'speed_marks'=>$stud_data['speed_marks'],'letter_id'=>$stud_data['letter_id'],'letter_base64'=>$stud_data['letter_base64'],'letter_text'=>$stud_data['letter_text'],'letter_html'=>$stud_data['letter_html'],'letter_marks'=>$stud_data['letter_marks'],'statement_id'=>$stud_data['statement_id'],'statement_text'=>$stud_data['statement_text'],'statement_html'=>$stud_data['statement_html'],'statement_base64'=>$stud_data['statement_base64'],'statement_marks'=>$stud_data['statement_marks'],'mobile_que'=>$stud_data['mobile_que'],'mobile_ans'=>$stud_data['mobile_ans'],'mobile_marks'=>$stud_data['mobile_marks'],'submit_on'=>$stud_data['submit_on'],'grace'=>$stud_data['grace']);
              
              $this->common_model->updateDetails('tbl_student','student_id',$result_data->student_id,$s_data);
              $this->common_model->addData('tbl_student_result',$r_data);
              foreach ($ans_data as $row ) 
              {
                  $data_ans[] = array('student_id'=>$row['stud_id'],'question_id'=>$row['question_id'],'stud_option_id'=>$row['stud_option_id']);
              }
              $this->common_model->SaveMultiData('tbl_user_answer',$data_ans);
          }
          else
          {
              if($result_data->objective_marks < $stud_data['objective_marks'] OR $result_data->speed_marks < $stud_data['speed_marks'])
              {
                  $s_data=array('exam_status'=>'Upload','objective_marks'=>$stud_data['objective_marks'],'email_marks'=>$stud_data['email_marks'],'speed_marks'=>$stud_data['speed_marks'],'letter_marks'=>$stud_data['letter_marks'],'statement_marks'=>$stud_data['statement_marks'],'mobile_marks'=>$stud_data['mobile_marks'],'submit_on'=>$stud_data['submit_on'],'grace'=>$stud_data['grace']);

                  $r_data=array('student_id'=>$stud_data['stud_id'],'objective_marks'=>$stud_data['objective_marks'],'email_id'=>$stud_data['email_id'],'to'=>$stud_data['to'],'cc'=>$stud_data['cc'],'bcc'=>$stud_data['bcc'],'subject'=>$stud_data['subject'],'message'=>$stud_data['message'],'attachment_file'=>$stud_data['attachment_file'],'attachment_file1'=>$stud_data['attachment_file1'],'email_marks'=>$stud_data['email_marks'],'speed_id'=>$stud_data['speed_id'],'passage'=>$stud_data['passage'],'speed_marks'=>$stud_data['speed_marks'],'letter_id'=>$stud_data['letter_id'],'letter_base64'=>$stud_data['letter_base64'],'letter_text'=>$stud_data['letter_text'],'letter_html'=>$stud_data['letter_html'],'letter_marks'=>$stud_data['letter_marks'],'statement_id'=>$stud_data['statement_id'],'statement_text'=>$stud_data['statement_text'],'statement_html'=>$stud_data['statement_html'],'statement_base64'=>$stud_data['statement_base64'],'statement_marks'=>$stud_data['statement_marks'],'mobile_que'=>$stud_data['mobile_que'],'mobile_ans'=>$stud_data['mobile_ans'],'mobile_marks'=>$stud_data['mobile_marks'],'submit_on'=>$stud_data['submit_on'],'grace'=>$stud_data['grace']);

                  $this->common_model->updateDetails('tbl_student','student_id',$result_data->student_id,$s_data);
                  $this->db->where('student_id',$stud_data['stud_id'])->delete('tbl_student_result');
                  $this->common_model->addData('tbl_student_result',$r_data);
                  $this->db->where('student_id',$stud_data['stud_id'])->delete('tbl_user_answer');
                  foreach ($ans_data as $row) 
                  {
                      $data_ans[] = array('stud_id'=>$row['stud_id'],'question_id'=>$row['question_id'],'stud_option_id'=>$row['stud_option_id']);
                  }
                  $this->common_model->SaveMultiData('tbl_user_answer',$data_ans);
              }
          }
          $stud_id[] = array('stud_id' => $stud_data['stud_id'] , 'exam_status'=>'Upload');
          $this->common_model->updateDetails('tbl_institute','institute_id',$result_data->institute_id,$data1);
        }
        $result=$this->db->trans_complete();
        
      }
            
      if(isset($result)&& !empty($result))
      {
          $json = array("status" => 1, "stud_id"=>$stud_id, "abc"=>"abc");
      }
      else
      {
          $stud_id[] = array('stud_id' => 1 , 'exam_status'=>'Pending');
          $json = array("status" => 1, "stud_id"=>$stud_id, "xyz"=>$this->db->last_query());
      }
      echo json_encode($json);
  }

  public function update_result()
  {
    $stud_data=$this->web_model->set_result(); 
    foreach ($stud_data as $key) 
    {   
      if($key->stud_course==7)
      {
        if($key->speed_marks ==20)   
        {   
          $letter_marks=rand(18,20);
          $statement_marks=rand(13,15);
        }
        else if($key->speed_marks > 15)   
        {   
          $letter_marks=rand(15,18);
          $statement_marks=rand(11,13);
        }
        else if($key->speed_marks > 10)   
        {   
          $letter_marks=rand(14,17);
          $statement_marks=rand(9,12);
        }
        else  
        {
          $letter_marks=rand(10,14);
          $statement_marks=rand(7,9);
        }
          
        $data=array('letter_marks'=>$letter_marks,'statement_marks'=>$statement_marks,'flag'=>'1');

        if($key->objective_marks==14 && $key->speed_marks >= 8)
        {
          $data['grace1']='*';
          $data['objective_marks']=16;
        }

        if($key->objective_marks >=14 && $key->speed_marks >= 8 && $key->speed_marks < 10 )
        {
          $data['grace']='*';
          $data['speed_marks']=10;
        }     
      }
      else
      {
        if($key->speed_marks ==20)   
        {   
          $letter_marks=rand(13,15);
          $statement_marks=rand(8,10);
        }
        else if($key->speed_marks > 15)   
        {   
          $letter_marks=rand(12,14);
          $statement_marks=rand(7,9);
        }
        else if($key->speed_marks > 10)   
        {   
          $letter_marks=rand(8,12);
          $statement_marks=rand(6,8);
        }
        else  
        {
          $letter_marks=rand(7,10);
          $statement_marks=rand(5,7);
        }
          
        $data=array('letter_marks'=>$letter_marks,'statement_marks'=>$statement_marks,'flag'=>'1');

        if($key->objective_marks==24 && $key->speed_marks >= 8)
        {
          $data['grace1']='*';
          $data['objective_marks']=26;
        }

        if($key->objective_marks >=24 && $key->speed_marks >= 8 && $key->speed_marks < 10 )
        {
          $data['grace']='*';
          $data['speed_marks']=10;
        }        
      }
      $this->db->trans_start(); 
        $this->common_model->updateDetails('tbl_student','stud_id',$key->stud_id,$data);
        $this->common_model->updateDetails('tbl_student_result','stud_id',$key->stud_id,$data);
      $result=$this->db->trans_complete();
    }
    echo 'result update Successfully';
  }
  
  public function advertise_link()
  {
    $this->load->view('site/advertise_link');
  }

  public function update_speed_marks()
  {
    $data['speed_data']=$this->web_model->featch_100_data1();
    $this->load->view('master/test1',$data);
  }
      
  public function update_speed_mark_new()
  {
    $stud_id=$this->input->post('s_id');
    $marks=$this->input->post('t_marks');
    for ($i=0; $i < count($stud_id) ; $i++) { 
        $stud[]=array('stud_id' =>$stud_id[$i],'speed_marks'=>$marks[$i],'speed_mark_set'=>'Y');
        $stud1[]=array('stud_id' =>$stud_id[$i],'speed_marks'=>$marks[$i]);
    }
    $this->db->trans_start(); 
        $this->common_model->update_batch('tbl_student_result',$stud,'stud_id');
        $this->common_model->update_batch('tbl_student',$stud1,'stud_id');
    $result=$this->db->trans_complete();
    if($result)
    {
        $this->json->jsonReturn(array(  
            'valid'=>TRUE,
            'msg'=>'<div class="alert modify alert-success"><strong></strong>Marks Details Saved Successfully!</div>'
        ));
    }
  }
  
  public function update_email_marks()
  {
    $data['email_data']=$this->web_model->featch_100_data();
    $this->load->view('master/test',$data);
  }
  
  public function update_email_mark_new()
  {
    $stud_id=$this->input->post('s_id');
    $marks=$this->input->post('t_marks');
    for ($i=0; $i < count($stud_id) ; $i++) { 
        $stud[]=array('stud_id' =>$stud_id[$i],'email_marks'=>$marks[$i],'email_mark_set'=>'Y');
        $stud1[]=array('stud_id' =>$stud_id[$i],'email_marks'=>$marks[$i]);
    }
    $this->db->trans_start(); 
        $this->common_model->update_batch('tbl_student_result',$stud,'stud_id');
        $this->common_model->update_batch('tbl_student',$stud1,'stud_id');
    $result=$this->db->trans_complete();
    if($result)
    {
        $this->json->jsonReturn(array(  
            'valid'=>TRUE,
            'msg'=>'<div class="alert modify alert-success"><strong></strong>Marks Details Saved Successfully!</div>'
        ));
    }
  }
  
}