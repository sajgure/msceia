<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
-------------------------------------------------------------
Author  : Abhijeet Gawande               Date: 27 Feb 20
-------------------------------------------------------------
*/

class Course_master_web extends Base_Controller {

    public function course_list()
    {
        $this->load->view('course-list');
    }

    public function add_course()
    {
        $this->load->view('add-course');
    }

    public function delete_city()
    {

    }

    public function edit_city()
    {

    }
}
