<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['superadmin'] ="login/login_controller/index";
$route['chk_login'] ='login/login_controller/chk_login';
$route['logout'] ='login/login_controller/logout';
