<?php defined('BASEPATH') OR exit('No direct script access allowed');

$route['check_user']='web/web_controller/check_user';
$route['get_msceia_student']='web/web_controller/get_msceia_student';
$route['fetch_video']='web/Web_controller/fetch_video';
$route['get_version']='web/Web_controller/get_version';
$route['redirect_link']='web/Web_controller/redirect_link';
$route['advertise_link']='web/Web_controller/advertise_link';
$route['check_update']='web/Web_controller/check_update';


$route['upload_db']='web/Web_controller/upload_db';
$route['app_login']='web/Web_controller/app_login';
$route['check_fek_user']='web/Web_controller/check_fek_user';
$route['update_result']='web/Web_controller/update_result';


$route['app_login1'] = 'web/web_controller/app_login1';

$route['app_login2'] = 'web/web_controller/app_login2';
$route['ques_data'] = 'web/web_controller/allQuesData';
$route['prev_data'] = 'web/web_controller/allPrevData';
$route['sec_data'] = 'web/web_controller/allSecData';

$route['only_question_data'] = 'web/web_controller/onlyQuesData';
$route['only_option_data'] = 'web/web_controller/onlyOptionData';
$route['only_prev_question_data'] = 'web/web_controller/onlyPrevQuesData';
$route['only_prev_option_data'] = 'web/web_controller/onlyPrevOptionData';

$route['update_email_mark_new'] = 'web/web_controller/update_email_mark_new';
$route['update_speed_mark_new'] = 'web/web_controller/update_speed_mark_new';

$route['fetch_pin_code_wise_inst'] = 'web/web_controller/fetchPinCodeWiseInst';