<div class="form-body">
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover datatable" data-url="<?php echo $url; ?>">
			<thead>
				<tr class="heading">
					<th class="font-blue-madison bold" scope="col">Sr. No.</th>
					<th class="font-blue-madison bold" scope="col">Student <br>Name</th>
					<th class="font-blue-madison bold" scope="col">Institute Name<br>Institute Code</th>
					<th class="font-blue-madison bold" scope="col">Email Id<br>Mobile No</th>
					<th class="font-blue-madison bold" scope="col">Course <br>Name</th>
					<th class="font-blue-madison bold" scope="col">District</th>
					<th class="font-blue-madison bold" scope="col">Seat No &<br> Password</th>
					<th class="font-blue-madison bold" scope="col">Status</th>
					<th class="font-blue-madison bold" scope="col">Reset Mac</th>
				</tr>
			</thead>
			<tbody> 
			</tbody>
		</table>
	</div>		
</div>