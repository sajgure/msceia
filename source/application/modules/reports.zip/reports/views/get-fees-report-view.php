
<div class="col-md-12">
    <div class="portlet box">
        <div class="portlet-body">
            <table class="table table-striped table-bordered table-hover datatable" data-url="<?php echo $url;?>" style="width: 100% !important;">
                <thead>
                    <tr class="heading">
                        <th class="font-blue-madison bold" style="text-align: center;width: 5%;">#</th>
                        <th class="font-blue-madison bold" style="width: 12.5%;">Institute <br>Details</th>
                        <th class="font-blue-madison bold" style="width: 12.5%;">Depositer<br> Name</th>
                        <th class="font-blue-madison bold" style="width: 5%;">Deposite <br> Date</th>
                        <th class="font-blue-madison bold" style="width: 5%;">Total <br>Student</th>
                        <th class="font-blue-madison bold" style="width: 10%;">Total<br> Amount</th>
                        <th class="font-blue-madison bold" style="width: 10%;">Payment<br> Mode</th>
                        <th class="font-blue-madison bold" style="width: 10%;">Transaction <br>Number</th>
                        <th class="font-blue-madison bold" style="width: 12.5%;">Remark</th>
                        <th class="font-blue-madison bold" style="width: 10%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>